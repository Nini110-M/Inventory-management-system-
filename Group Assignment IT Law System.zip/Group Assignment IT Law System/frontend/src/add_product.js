//add_product.js

document.addEventListener("DOMContentLoaded", () => {
  const addProductForm = document.getElementById("addProductForm");
  const productTableBody = document.getElementById("productTableBody");

  productTableBody.addEventListener("click", async (event) => {
    if (event.target.matches("button[data-action='editProduct']")) {
      const productId = event.target.dataset.productId;
      await editProduct(productId);
    }
  });

  // Function to fetch products and render them in the table
  const fetchProducts = async () => {
    try {
      const response = await fetch("http://localhost:3001/api/products");
      if (response.ok) {
        const products = await response.json();
        productTableBody.innerHTML = ""; // Clear table body
        products.forEach((product) => {
          const row = `
              <tr data-productId="${product.productID}">
                <td>${product.productID}</td>
                <td>${product.productName}</td>
                <td>${product.category}</td>
                <td>${product.unitPrice}</td>
                <td>${product.quantityInStock}</td>
                <td>${product.reorderLevel}</td>
                <td>${product.supplierName}</td>
                <td>
                  <button onclick="editProduct('${product._id}')">Edit</button>
                  <button onclick="deleteProduct('${product._id}')">Delete</button>
                </td>
              </tr>
            `;
          productTableBody.innerHTML += row;
        });
      } else {
        console.error("Failed to fetch products");
      }
    } catch (error) {
      console.error("Error:", error);
    }
  };

  // Function to handle form submission (add new product or update existing product)
  const handleFormSubmit = async (event, productId) => {
    event.preventDefault();
    const productID = document.getElementById("productID").value;
    const productName = document.getElementById("productName").value;
    const category = document.getElementById("category").value;
    const unitPrice = document.getElementById("unitPrice").value;
    const quantityInStock = document.getElementById("quantityInStock").value;
    const reorderLevel = document.getElementById("reorderLevel").value;
    const supplierName = document.getElementById("supplierName").value;

    try {
      let response;
      if (productId) {
        // Update existing product
        response = await fetch(`http://localhost:3001/api/products/`, {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            productID,
            productName,
            category,
            unitPrice: Number(unitPrice),
            quantityInStock: Number(quantityInStock),
            reorderLevel: Number(reorderLevel),
            supplierName,
          }),
        });
      } else {
        // Add new product
        response = await fetch("http://localhost:3001/api/products", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            productID,
            productName,
            category,
            unitPrice: Number(unitPrice),
            quantityInStock: Number(quantityInStock),
            reorderLevel: Number(reorderLevel),
            supplierName,
          }),
        });
      }

      if (response.ok) {
        await fetchProducts(); // Refresh product list after adding or updating
        addProductForm.reset(); // Reset form fields
      } else {
        console.error(
          `Failed to ${productId ? "update" : "add"} product: ${
            response.status
          } ${response.statusText}`
        );
        const errorResponse = await response.json();
        console.error("Server Error Details:", errorResponse);
      }
    } catch (error) {
      console.error("Error:", error);
    }
  };

  // Function to handle edit product operation
  const editProduct = async (productId) => {
    try {
      const response = await fetch(
        `http://localhost:3001/api/products/${productId}`
      );
      if (response.ok) {
        const product = await response.json();

        // Populate form fields with product data
        document.getElementById("productID").value = product.productID;
        document.getElementById("productName").value = product.productName;
        document.getElementById("category").value = product.category;
        document.getElementById("unitPrice").value = product.unitPrice;
        document.getElementById("quantityInStock").value =
          product.quantityInStock;
        document.getElementById("reorderLevel").value = product.reorderLevel;
        document.getElementById("supplierName").value = product.supplierName;

        // Change submit button to update mode
        const submitButton = document.querySelector('button[type="submit"]');
        submitButton.textContent = "Update Product";
        submitButton.onclick = (event) => handleFormSubmit(event, productId);
      } else {
        console.error("Failed to fetch product for editing:", response.status);
      }
    } catch (error) {
      console.error("Error fetching product:", error);
    }
  };

  // Function to handle delete product operation
  window.deleteProduct = async (productId) => {
    try {
      const response = await fetch(
        `http://localhost:3001/api/products/${productId}`,
        {
          method: "DELETE",
        }
      );
      if (response.ok) {
        await fetchProducts(); // Refresh product list after deletion
      } else {
        console.error("Failed to delete product");
      }
    } catch (error) {
      console.error("Error:", error);
    }
  };

  // Attach form submission handler
  addProductForm.addEventListener("submit", (event) => handleFormSubmit(event));

  // Initial fetch of products when the page loads
  fetchProducts();
});
