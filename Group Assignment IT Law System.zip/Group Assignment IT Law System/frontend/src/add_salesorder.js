// salesorders.js

document.addEventListener("DOMContentLoaded", () => {
  const addSalesOrderForm = document.getElementById("addSalesOrderForm");
  const salesOrderTableBody = document.getElementById("salesOrderTableBody");

  const fetchSalesOrders = async () => {
    try {
      const response = await fetch("http://localhost:3001/api/sales-orders");
      if (response.ok) {
        const salesOrders = await response.json();
        salesOrderTableBody.innerHTML = ""; // Clear table body
        salesOrders.forEach((order) => {
          const row = `
              <tr>
                <td>${order.orderId}</td>
                <td>${order.customerId}</td>
                <td>${new Date(order.orderDate).toLocaleDateString()}</td>
                <td>${order.orderStatus}</td>
                <td>${order.productID}</td>
                <td>${order.quantity}</td>
                <td>
                  <button onclick="editSalesOrder('${order._id}')">Edit</button>
                  <button onclick="deleteSalesOrder('${
                    order._id
                  }')">Delete</button>
                </td>
              </tr>
            `;
          salesOrderTableBody.innerHTML += row;
        });
      } else {
        console.error("Failed to fetch sales orders");
      }
    } catch (error) {
      console.error("Error:", error);
    }
  };

  window.editSalesOrder = (orderId) => {
    window.location.href = `edit_salesorder.html?id=${orderId}`;
  };

  addSalesOrderForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    const orderId = document.getElementById("orderId").value;
    const customerId = document.getElementById("customerId").value;
    const orderDate = document.getElementById("orderDate").value;
    const orderStatus = document.getElementById("orderStatus").value;
    const productID = document.getElementById("productID").value;
    const quantity = document.getElementById("quantity").value;

    try {
      const response = await fetch("http://localhost:3001/api/sales-orders", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          orderId,
          customerId,
          orderDate,
          orderStatus,
          productID,
          quantity: parseInt(quantity), // Ensure quantity is sent as a number
        }),
      });

      if (response.ok) {
        await fetchSalesOrders(); // Refresh sales order list after adding
        addSalesOrderForm.reset(); // Reset form fields
      } else {
        console.error(
          `Failed to add sales order: ${response.status} ${response.statusText}`
        );
        const errorResponse = await response.json();
        console.error("Server Error Details:", errorResponse);
      }
    } catch (error) {
      console.error("Error:", error);
    }
  });

  window.deleteSalesOrder = async (orderId) => {
    try {
      const response = await fetch(
        `http://localhost:3001/api/sales-orders/${orderId}`,
        {
          method: "DELETE",
        }
      );
      if (response.ok) {
        await fetchSalesOrders(); // Refresh sales order list after deletion
      } else {
        console.error("Failed to delete sales order");
      }
    } catch (error) {
      console.error("Error:", error);
    }
  };

  // Initial fetch of sales orders when the page loads
  fetchSalesOrders();
});
