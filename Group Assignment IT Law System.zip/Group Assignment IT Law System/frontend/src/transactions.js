document.addEventListener("DOMContentLoaded", () => {
  const transactionTableBody = document.getElementById("transactionTableBody");
  const searchBar = document.getElementById("searchBar");

  let allTransactions = [];

  const fetchTransactions = async () => {
    try {
      const response = await fetch("http://localhost:3001/api/transactions");
      if (response.ok) {
        const transactions = await response.json();
        allTransactions = transactions; // Store all transactions for filtering
        displayTransactions(transactions);
      } else {
        console.error("Failed to fetch transactions");
      }
    } catch (error) {
      console.error("Error:", error);
    }
  };

  const displayTransactions = (transactions) => {
    transactionTableBody.innerHTML = ""; // Clear table body
    transactions.forEach((transaction) => {
      const row = `
        <tr>
          <td>${transaction.transactionId}</td>
          <td>${transaction.productID}</td>
          <td>${transaction.transactionType}</td>
          <td>${transaction.transactionDate.split("T")[0]}</td>
          <td>${transaction.quantity}</td>
          <td>${transaction.unitPrice}</td>
          <td>${transaction.transactionAmount}</td>
          <td>${transaction.supplierId || ""}</td>
          <td>${transaction.customerId || ""}</td>
          <td>
            <button onclick="editTransaction('${
              transaction.transactionId
            }')">Edit</button>
            <button onclick="deleteTransaction('${
              transaction._id
            }')">Delete</button>
          </td>
        </tr>
      `;
      transactionTableBody.innerHTML += row;
    });
  };

  window.editTransaction = (transactionId) => {
    window.location.href = `edit_transaction.html?id=${transactionId}`;
  };

  window.deleteTransaction = async (transactionId) => {
    try {
      const response = await fetch(
        `http://localhost:3001/api/transactions/${transactionId}`,
        {
          method: "DELETE",
        }
      );
      if (response.ok) {
        await fetchTransactions(); // Refresh transaction list after deletion
      } else {
        console.error("Failed to delete transaction");
      }
    } catch (error) {
      console.error("Error:", error);
    }
  };

  // Filter transactions based on search input
  searchBar.addEventListener("input", (event) => {
    const searchTerm = event.target.value.toLowerCase();
    const filteredTransactions = allTransactions.filter((transaction) => {
      return (
        transaction.transactionId.toLowerCase().includes(searchTerm) ||
        transaction.productID.toLowerCase().includes(searchTerm) ||
        transaction.transactionType.toLowerCase().includes(searchTerm) ||
        transaction.transactionDate.toLowerCase().includes(searchTerm) ||
        transaction.quantity.toString().toLowerCase().includes(searchTerm) ||
        transaction.unitPrice.toString().toLowerCase().includes(searchTerm) ||
        transaction.transactionAmount
          .toString()
          .toLowerCase()
          .includes(searchTerm) ||
        (transaction.supplierId &&
          transaction.supplierId.toLowerCase().includes(searchTerm)) ||
        (transaction.customerId &&
          transaction.customerId.toLowerCase().includes(searchTerm))
      );
    });
    displayTransactions(filteredTransactions);
  });

  // Initial fetch of transactions when the page loads
  fetchTransactions();
});
