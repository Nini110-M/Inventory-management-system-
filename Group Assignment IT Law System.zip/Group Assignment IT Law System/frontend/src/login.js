document.addEventListener("DOMContentLoaded", () => {
  document
    .getElementById("loginForm")
    .addEventListener("submit", async (event) => {
      event.preventDefault();

      const username = document.getElementById("usernameInput").value;
      const password = document.getElementById("passwordInput").value;

      try {
        const response = await fetch("http://localhost:3001/api/login", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ username, password }),
        });

        if (response.ok) {
          const data = await response.json();
          console.log(data); // handle response data accordingly
          window.location.href = "dashboard.html";
        } else {
          const errorData = await response.text();
          console.error("Login failed:", errorData);
          alert("Login failed. Please try again.");
        }
      } catch (error) {
        console.error("Error:", error);
        alert("An error occurred. Please try again later.");
      }
    });
});
