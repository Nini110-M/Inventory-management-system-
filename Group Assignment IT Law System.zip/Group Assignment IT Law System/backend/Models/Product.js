// Models/Product.js

const mongoose = require("mongoose");

const productSchema = new mongoose.Schema({
  productID: { type: String, required: true, unique: true },
  productName: { type: String, required: true },
  category: { type: String, required: true },
  unitPrice: { type: Number, required: true },
  quantityInStock: { type: Number, required: true },
  reorderLevel: { type: Number, required: true },
  supplierName: { type: String, required: true },
});

const Product = mongoose.model("Product", productSchema);

module.exports = Product;
