const mongoose = require("mongoose");

const purchaseOrderSchema = new mongoose.Schema({
  orderId: { type: String, required: true },
  supplierId: { type: String, required: true },
  orderDate: { type: Date, required: true },
  orderStatus: { type: String, required: true },
  productID: { type: String, required: true },
  quantity: { type: Number, required: true },
});

const PurchaseOrder = mongoose.model("PurchaseOrder", purchaseOrderSchema);

module.exports = PurchaseOrder;
