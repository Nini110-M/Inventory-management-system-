document.addEventListener("DOMContentLoaded", () => {
  const addProductForm = document.getElementById("addProductForm");
  const productTableBody = document.getElementById("productTableBody");
  const searchBar = document.getElementById("searchBar");

  let allProducts = [];

  const fetchProducts = async () => {
    try {
      const response = await fetch("http://localhost:3001/api/products");
      if (response.ok) {
        const products = await response.json();
        allProducts = products; // Store all products for filtering
        displayProducts(products);
      } else {
        console.error("Failed to fetch products");
      }
    } catch (error) {
      console.error("Error:", error);
    }
  };

  const displayProducts = (products) => {
    productTableBody.innerHTML = ""; // Clear table body
    products.forEach((product) => {
      const row = `
        <tr>
          <td>${product.productID}</td>
          <td>${product.productName}</td>
          <td>${product.category}</td>
          <td>${product.unitPrice}</td>
          <td>${product.quantityInStock}</td>
          <td>${product.reorderLevel}</td>
          <td>${product.supplierName}</td>
          <td>
            <button onclick="editProduct('${product.productID}')">Update</button>
            <button onclick="deleteProduct('${product._id}')">Delete</button>
            <button onclick="retrieveProduct('${product.productID}')">Retrieve</button>
          </td>
        </tr>
      `;
      productTableBody.innerHTML += row;
    });
  };

  window.editProduct = (productId) => {
    window.location.href = `edit_product.html?id=${productId}`;
  };

  window.retrieveProduct = (productId) => {
    window.location.href = `retrieve_product.html?id=${productId}`;
  };

  addProductForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    const productID = document.getElementById("productID").value;
    const productName = document.getElementById("productName").value;
    const category = document.getElementById("category").value;
    const unitPrice = document.getElementById("unitPrice").value;
    const quantityInStock = document.getElementById("quantityInStock").value;
    const reorderLevel = document.getElementById("reorderLevel").value;
    const supplierName = document.getElementById("supplierName").value;

    try {
      const response = await fetch("http://localhost:3001/api/products", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          productID,
          productName,
          category,
          unitPrice: Number(unitPrice),
          quantityInStock: Number(quantityInStock),
          reorderLevel: Number(reorderLevel),
          supplierName,
        }),
      });

      if (response.ok) {
        await fetchProducts(); // Refresh product list after adding
        addProductForm.reset(); // Reset form fields
      } else {
        console.error(
          `Failed to add product: ${response.status} ${response.statusText}`
        );
        const errorResponse = await response.json();
        console.error("Server Error Details:", errorResponse);
      }
    } catch (error) {
      console.error("Error:", error);
    }
  });

  window.deleteProduct = async (productId) => {
    try {
      const response = await fetch(
        `http://localhost:3001/api/products/${productId}`,
        {
          method: "DELETE",
        }
      );
      if (response.ok) {
        await fetchProducts(); // Refresh product list after deletion
      } else {
        console.error("Failed to delete product");
      }
    } catch (error) {
      console.error("Error:", error);
    }
  };

  // Filter products based on search input
  searchBar.addEventListener("input", (event) => {
    const searchTerm = event.target.value.toLowerCase();
    const filteredProducts = allProducts.filter((product) => {
      return (
        product.productID.toLowerCase().includes(searchTerm) ||
        product.productName.toLowerCase().includes(searchTerm) ||
        product.category.toLowerCase().includes(searchTerm) ||
        product.unitPrice.toString().toLowerCase().includes(searchTerm) ||
        product.quantityInStock.toString().toLowerCase().includes(searchTerm) ||
        product.reorderLevel.toString().toLowerCase().includes(searchTerm) ||
        product.supplierName.toLowerCase().includes(searchTerm)
      );
    });
    displayProducts(filteredProducts);
  });

  // Initial fetch of products when the page loads
  fetchProducts();
});
