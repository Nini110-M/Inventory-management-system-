document.addEventListener("DOMContentLoaded", () => {
  const revenueCalculatorForm = document.getElementById(
    "revenueCalculatorForm"
  );
  const totalRevenueSpan = document.getElementById("totalRevenue");
  const productsSoldTableBody = document.getElementById(
    "productsSoldTableBody"
  );

  revenueCalculatorForm.addEventListener("submit", async (event) => {
    event.preventDefault();

    const startDate = document.getElementById("startDate").value;
    const endDate = document.getElementById("endDate").value;

    try {
      const response = await fetch(
        `http://localhost:3001/api/transactions/revenue`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ startDate, endDate }),
        }
      );

      if (response.ok) {
        const data = await response.json();
        const { totalRevenue, productsSold } = data;

        totalRevenueSpan.textContent = totalRevenue.toFixed(2);

        productsSoldTableBody.innerHTML = "";
        productsSold.forEach((product) => {
          const row = `
              <tr>
                <td>${product.productID}</td>
                <td>${product.quantity}</td>
                <td>${product.totalAmount.toFixed(2)}</td>
              </tr>
            `;
          productsSoldTableBody.innerHTML += row;
        });
      } else {
        console.error("Failed to calculate revenue");
      }
    } catch (error) {
      console.error("Error:", error);
    }
  });
});
