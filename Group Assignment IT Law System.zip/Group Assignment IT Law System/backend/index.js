const express = require("express");
const mongoose = require("mongoose");
const bodyParser = require("body-parser");
const cors = require("cors"); // Import cors package
const path = require("path");

const app = express(); // Create an Express application

app.use(bodyParser.json());

const PORT = process.env.PORT || 3001;

// Middleware to parse JSON bodies
app.use(express.json());

// Other middleware setup
app.use(cors()); // Enable CORS for all routes

// Serve static files from the "frontend" directory
app.use(express.static(path.join(__dirname, "frontend")));

// Import API routes
const apiRoutes = require("./routes/api");

// Use API routes
app.use("/api", apiRoutes);

// Connect to MongoDB using mongoose
mongoose
  .connect("mongodb://localhost:27017/Inventory", {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(() => {
    console.log("Connected to database..");
  })
  .catch((error) => {
    console.error("Failed to connect to database:", error);
  });

// Start the server
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
