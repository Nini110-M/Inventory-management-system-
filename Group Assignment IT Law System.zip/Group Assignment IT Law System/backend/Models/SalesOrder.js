// Models/SalesOrder.js

const mongoose = require("mongoose");

const salesOrderSchema = new mongoose.Schema({
  orderId: { type: String, required: true },
  customerId: { type: String, required: true },
  orderDate: { type: Date, required: true },
  orderStatus: { type: String, required: true },
  productID: { type: String, required: true },
  quantity: { type: Number, required: true },
});

const SalesOrder = mongoose.model("SalesOrder", salesOrderSchema);

module.exports = SalesOrder;
