document.addEventListener("DOMContentLoaded", async () => {
  const lowStockChartCtx = document
    .getElementById("lowStockChart")
    .getContext("2d");
  const salesPerformanceChartCtx = document
    .getElementById("salesPerformanceChart")
    .getContext("2d");

  const fetchProducts = async () => {
    try {
      const response = await fetch("http://localhost:3001/api/products");
      if (response.ok) {
        return await response.json();
      } else {
        console.error("Failed to fetch products");
        return [];
      }
    } catch (error) {
      console.error("Error:", error);
      return [];
    }
  };

  const fetchTransactions = async () => {
    try {
      const response = await fetch("http://localhost:3001/api/transactions");
      if (response.ok) {
        return await response.json();
      } else {
        console.error("Failed to fetch transactions");
        return [];
      }
    } catch (error) {
      console.error("Error:", error);
      return [];
    }
  };

  const products = await fetchProducts();
  const transactions = await fetchTransactions();

  // Filter products with stock levels less than or equal to 21
  const lowStockProducts = products.filter(
    (product) => product.quantityInStock <= 20
  );
  const lowStockData = {
    labels: lowStockProducts.map((product) => product.productName),
    datasets: [
      {
        label: "Quantity in Stock",
        data: lowStockProducts.map((product) => product.quantityInStock),
        backgroundColor: "rgba(54, 162, 235, 0.2)",
        borderColor: "grey",
        borderWidth: 1,
      },
    ],
  };

  new Chart(lowStockChartCtx, {
    type: "bar",
    data: lowStockData,
    options: {
      responsive: true,
      maintainAspectRatio: false,
      scales: {
        x: {
          beginAtZero: true,
        },
        y: {
          beginAtZero: true,
        },
      },
    },
  });

  const salesTransactions = transactions.filter(
    (transaction) => transaction.transactionType === "Sale"
  );
  const salesDates = salesTransactions.map(
    (transaction) => transaction.transactionDate.split("T")[0]
  );
  const salesAmounts = salesTransactions.map(
    (transaction) => transaction.transactionAmount
  );
  const salesPerformanceData = {
    labels: salesDates,
    datasets: [
      {
        label: "Sales Amount",
        data: salesAmounts,
        backgroundColor: "rgba(54, 162, 235, 0.2)",
        borderColor: "rgba(54, 162, 235, 1)",
        borderWidth: 2,
      },
    ],
  };

  new Chart(salesPerformanceChartCtx, {
    type: "line",
    data: salesPerformanceData,
    options: {
      responsive: true,
      maintainAspectRatio: false,
      scales: {
        x: {
          beginAtZero: true,
        },
        y: {
          beginAtZero: true,
        },
      },
    },
  });
});
