document.addEventListener("DOMContentLoaded", () => {
  document
    .getElementById("registerForm")
    .addEventListener("submit", async (event) => {
      event.preventDefault();

      const username = document.getElementById("usernameInput").value;
      const email = document.getElementById("emailInput").value;
      const password = document.getElementById("passwordInput").value;

      try {
        const response = await fetch("http://localhost:3001/api/register", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ username, email, password }),
        });

        if (response.ok) {
          const data = await response.json();
          console.log(data); // handle response data accordingly
          alert("Registration successful. You can now log in.");
          window.location.href = "login.html"; // Redirect to login page after successful registration
        } else {
          const errorData = await response.json();
          console.error("Registration failed:", errorData.error);
          alert("Registration failed. Please try again.");
        }
      } catch (error) {
        console.error("Error:", error);
        alert("An error occurred. Please try again later.");
      }
    });
});
