document.addEventListener("DOMContentLoaded", () => {
  const addTransactionForm = document.getElementById("addTransactionForm");
  const transactionTypeSelect = document.getElementById("transactionType");
  const supplierIdInput = document.getElementById("supplierId");
  const customerIdInput = document.getElementById("customerId");

  transactionTypeSelect.addEventListener("change", () => {
    if (transactionTypeSelect.value === "Sale") {
      supplierIdInput.style.display = "none";
      customerIdInput.style.display = "block";
    } else if (transactionTypeSelect.value === "Purchase") {
      customerIdInput.style.display = "none";
      supplierIdInput.style.display = "block";
    } else {
      supplierIdInput.style.display = "none";
      customerIdInput.style.display = "none";
    }
  });

  addTransactionForm.addEventListener("submit", async (event) => {
    event.preventDefault();

    const transactionId = document.getElementById("transactionId").value;
    const productID = document.getElementById("productID").value;
    const transactionType = document.getElementById("transactionType").value;
    const transactionDate = document.getElementById("transactionDate").value;
    const quantity = document.getElementById("quantity").value;
    const supplierId = document.getElementById("supplierId").value;
    const customerId = document.getElementById("customerId").value;

    try {
      const productResponse = await fetch(
        `http://localhost:3001/api/products/${productID}`
      );

      if (productResponse.ok) {
        const product = await productResponse.json();
        const unitPrice = product.unitPrice;
        const transactionAmount = unitPrice * quantity;

        const transactionData = {
          transactionId,
          productID,
          transactionType,
          transactionDate,
          quantity: Number(quantity),
          unitPrice: unitPrice,
          transactionAmount: transactionAmount,
        };

        if (transactionType === "Sale") {
          transactionData.customerId = customerId;
        } else {
          transactionData.supplierId = supplierId;
        }

        const response = await fetch("http://localhost:3001/api/transactions", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(transactionData),
        });

        if (response.ok) {
          alert("Transaction added successfully!");
          addTransactionForm.reset();
          window.location.href = "transactions.html";
        } else {
          console.error("Failed to add transaction");
          const errorResponse = await response.json();
          console.error("Server Error Details:", errorResponse);
        }
      } else {
        console.error("Failed to fetch product");
        alert("Product not found. Please check the Product ID and try again.");
      }
    } catch (error) {
      console.error("Error:", error);
      alert("An error occurred. Please try again later.");
    }
  });
});
