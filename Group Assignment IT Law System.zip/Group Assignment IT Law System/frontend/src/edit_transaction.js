document.addEventListener("DOMContentLoaded", () => {
  const editTransactionForm = document.getElementById("editTransactionForm");
  const transactionTypeSelect = document.getElementById("transactionType");
  const supplierIdInput = document.getElementById("supplierId");
  const customerIdInput = document.getElementById("customerId");

  // Retrieve transaction ID from URL parameters
  const urlParams = new URLSearchParams(window.location.search);
  const transactionId = urlParams.get("id");

  const fetchTransaction = async () => {
    try {
      const response = await fetch(
        `http://localhost:3001/api/transactions/by-transaction-id/${transactionId}`
      );
      if (response.ok) {
        const transaction = await response.json();
        console.log("Fetched transaction:", transaction); // Debug statement

        document.getElementById("transactionId").value =
          transaction.transactionId;
        document.getElementById("productID").value = transaction.productID;
        document.getElementById("transactionType").value =
          transaction.transactionType;
        document.getElementById("transactionDate").value =
          transaction.transactionDate.split("T")[0];
        document.getElementById("quantity").value = transaction.quantity;
        document.getElementById("supplierId").value =
          transaction.supplierId || "";
        document.getElementById("customerId").value =
          transaction.customerId || "";

        if (transaction.transactionType === "Sale") {
          supplierIdInput.style.display = "none";
          customerIdInput.style.display = "block";
        } else if (transaction.transactionType === "Purchase") {
          customerIdInput.style.display = "none";
          supplierIdInput.style.display = "block";
        }
      } else {
        console.error("Failed to fetch transaction for editing");
      }
    } catch (error) {
      console.error("Error:", error);
    }
  };

  transactionTypeSelect.addEventListener("change", () => {
    if (transactionTypeSelect.value === "Sale") {
      supplierIdInput.style.display = "none";
      customerIdInput.style.display = "block";
    } else if (transactionTypeSelect.value === "Purchase") {
      customerIdInput.style.display = "none";
      supplierIdInput.style.display = "block";
    } else {
      supplierIdInput.style.display = "none";
      customerIdInput.style.display = "none";
    }
  });

  editTransactionForm.addEventListener("submit", async (event) => {
    event.preventDefault();

    const transactionId = document.getElementById("transactionId").value;
    const productID = document.getElementById("productID").value;
    const transactionType = document.getElementById("transactionType").value;
    const transactionDate = document.getElementById("transactionDate").value;
    const quantity = Number(document.getElementById("quantity").value);
    const supplierId = document.getElementById("supplierId").value;
    const customerId = document.getElementById("customerId").value;

    try {
      const productResponse = await fetch(
        `http://localhost:3001/api/products/${productID}`
      );

      if (productResponse.ok) {
        const product = await productResponse.json();
        const unitPrice = product.unitPrice;
        const transactionAmount = unitPrice * quantity;

        const updatedData = {
          transactionId,
          productID,
          transactionType,
          transactionDate,
          quantity,
          unitPrice: unitPrice,
          transactionAmount: transactionAmount,
        };

        if (transactionType === "Sale") {
          updatedData.customerId = customerId;
        } else {
          updatedData.supplierId = supplierId;
        }

        const response = await fetch(
          `http://localhost:3001/api/transactions/by-transaction-id/${transactionId}`,
          {
            method: "PUT",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify(updatedData),
          }
        );

        if (response.ok) {
          alert("Transaction updated successfully!");
          window.location.href = "transactions.html";
        } else {
          console.error("Failed to update transaction");
        }
      } else {
        console.error("Failed to fetch product");
        alert("Product not found. Please check the Product ID and try again.");
      }
    } catch (error) {
      console.error("Error:", error);
    }
  });

  fetchTransaction();
});
