const mongoose = require("mongoose");

const warehouseSchema = new mongoose.Schema({
  warehouseId: { type: String, required: true },
  warehouseName: { type: String, required: true },
  warehouseAddress: { type: String, required: true },
});

const Warehouse = mongoose.model("Warehouse", warehouseSchema);

module.exports = Warehouse;
