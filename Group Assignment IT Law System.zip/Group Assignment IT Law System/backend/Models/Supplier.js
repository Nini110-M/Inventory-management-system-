const mongoose = require("mongoose");

const supplierSchema = new mongoose.Schema({
  supplierId: { type: String, required: true },
  supplierName: { type: String, required: true },
  contactName: { type: String },
  emailAddress: { type: String },
  phoneNumber: { type: String },
});

const Supplier = mongoose.model("Supplier", supplierSchema);

module.exports = Supplier;
