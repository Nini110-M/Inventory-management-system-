// routes/api.js

const express = require("express");
const router = express.Router();
const User = require("../Models/User");
const Product = require("../Models/Product");
const SalesOrder = require("../Models/SalesOrder");
const Transaction = require("../Models/Transaction");

// Route to register a new user
router.post("/register", async (req, res) => {
  try {
    const { username, email, password } = req.body;
    const newUser = new User({ username, email, password });
    await newUser.save();
    res
      .status(201)
      .json({ message: "User registered successfully", user: newUser });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Route for user login
router.post("/login", async (req, res) => {
  const { username, password } = req.body;

  try {
    const user = await User.findOne({ username, password });

    if (!user) {
      return res.status(401).json({ message: "Invalid username or password" });
    }

    res.status(200).json({ message: "Login successful", user });
  } catch (error) {
    console.error("Login error:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});

// CRUD operations for Product
router.post("/products", async (req, res) => {
  try {
    const productData = req.body;
    const product = new Product(productData);
    await product.save();
    res.status(201).json(product);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Corrected GET route for fetching product by productID
router.post("/products", async (req, res) => {
  try {
    const productData = req.body;
    const product = new Product(productData);
    await product.save();
    res.status(201).json(product);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

router.get("/products/:id", async (req, res) => {
  try {
    const { id } = req.params;

    // Search by productID if it's a valid string
    if (/^[a-zA-Z0-9]+$/.test(id)) {
      const product = await Product.findOne({ productID: id });

      if (product) {
        res.status(200).json(product);
      } else {
        res.status(404).json({ message: "Product not found" });
      }
    } else {
      // If not a valid productID, assume it's an ObjectId and search by _id
      const product = await Product.findById(id);

      if (product) {
        res.status(200).json(product);
      } else {
        res.status(404).json({ message: "Product not found" });
      }
    }
  } catch (error) {
    console.error("Error fetching product:", error);
    res.status(500).json({ message: "Internal server error" });
  }
});

router.get("/products", async (req, res) => {
  try {
    const products = await Product.find();
    res.status(200).json(products);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.get("/products/:id", async (req, res) => {
  try {
    const { id } = req.params;

    // Search by productID if it's a valid string
    if (/^[a-zA-Z0-9]+$/.test(id)) {
      const product = await Product.findOne({ productID: id });

      if (product) {
        res.status(200).json(product);
      } else {
        res.status(404).json({ message: "Product not found" });
      }
    } else {
      // If not a valid productID, assume it's an ObjectId and search by _id
      const product = await Product.findById(id);

      if (product) {
        res.status(200).json(product);
      } else {
        res.status(404).json({ message: "Product not found" });
      }
    }
  } catch (error) {
    console.error("Error fetching product:", error);
    res.status(500).json({ message: "Internal server error" });
  }
});

router.get("/products/:id", async (req, res) => {
  try {
    const { id } = req.params;
    const product = await Product.findById(id);

    if (product) {
      res.status(200).json(product);
    } else {
      res.status(404).json({ message: "Product not found" });
    }
  } catch (error) {
    console.error("Error fetching product:", error);
    res.status(500).json({ message: "Internal server error" });
  }
});

router.put("/products/:productID", async (req, res) => {
  try {
    const { productID } = req.params;
    const updatedProduct = await Product.findOneAndUpdate(
      { productID },
      req.body,
      { new: true }
    );

    if (updatedProduct) {
      res.status(200).json(updatedProduct);
    } else {
      res.status(404).json({ message: "Product not found" });
    }
  } catch (error) {
    console.error("Error updating product:", error);
    res.status(400).json({ error: error.message });
  }
});

router.delete("/products/:id", async (req, res) => {
  try {
    const { id } = req.params;
    await Product.findByIdAndDelete(id);
    res.status(204).end();
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// CRUD operations for SalesOrder
// Create a new sales order
router.post("/sales-orders", async (req, res) => {
  try {
    const orderData = req.body;
    const salesOrder = new SalesOrder(orderData);
    await salesOrder.save();
    res.status(201).json(salesOrder);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Retrieve all sales orders
router.get("/sales-orders", async (req, res) => {
  try {
    const salesOrders = await SalesOrder.find();
    res.status(200).json(salesOrders);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Update a sales order
router.put("/sales-orders/:id", async (req, res) => {
  try {
    const { id } = req.params;
    const updatedSalesOrder = await SalesOrder.findByIdAndUpdate(id, req.body, {
      new: true,
    });
    res.status(200).json(updatedSalesOrder);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Delete a sales order
router.delete("/sales-orders/:id", async (req, res) => {
  try {
    const { id } = req.params;
    await SalesOrder.findByIdAndDelete(id);
    res.status(204).end();
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// CRUD operations for Transaction
router.post("/transactions", async (req, res) => {
  try {
    const transactionData = req.body;
    const transaction = new Transaction(transactionData);
    await transaction.save();
    res.status(201).json(transaction);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

router.get("/transactions", async (req, res) => {
  try {
    const transactions = await Transaction.find();
    res.status(200).json(transactions);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.put("/transactions/:id", async (req, res) => {
  try {
    const { id } = req.params;
    const updatedTransaction = await Transaction.findByIdAndUpdate(
      id,
      req.body,
      { new: true }
    );
    res.status(200).json(updatedTransaction);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

router.delete("/transactions/:id", async (req, res) => {
  try {
    const { id } = req.params;
    await Transaction.findByIdAndDelete(id);
    res.status(204).end();
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

router.get("/transactions/period", async (req, res) => {
  const { startDate, endDate } = req.query;

  if (!startDate || !endDate) {
    return res
      .status(400)
      .json({ error: "Start date and end date are required" });
  }

  try {
    const transactions = await Transaction.find({
      transactionDate: {
        $gte: new Date(startDate),
        $lte: new Date(endDate),
      },
      transactionType: "Sale",
    });

    const totalSales = transactions.reduce(
      (acc, transaction) => acc + transaction.transactionAmount,
      0
    );

    res.status(200).json({ transactions, totalSales });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

router.get(
  "/transactions/by-transaction-id/:transactionId",
  async (req, res) => {
    try {
      const { transactionId } = req.params;
      const transaction = await Transaction.findOne({ transactionId });

      if (transaction) {
        res.status(200).json(transaction);
      } else {
        res.status(404).json({ message: "Transaction not found" });
      }
    } catch (error) {
      console.error("Error fetching transaction:", error);
      res.status(500).json({ message: "Internal server error" });
    }
  }
);

router.put(
  "/transactions/by-transaction-id/:transactionId",
  async (req, res) => {
    try {
      const { transactionId } = req.params;
      const updatedTransaction = await Transaction.findOneAndUpdate(
        { transactionId },
        req.body,
        { new: true }
      );

      if (updatedTransaction) {
        res.status(200).json(updatedTransaction);
      } else {
        res.status(404).json({ message: "Transaction not found" });
      }
    } catch (error) {
      console.error("Error updating transaction:", error);
      res.status(400).json({ error: error.message });
    }
  }
);
router.post(
  "/transactions/by-transaction-id/:transactionId",
  async (req, res) => {
    try {
      const { transactionId } = req.params;
      const updatedTransaction = await Transaction.findOneAndUpdate(
        { transactionId },
        req.body,
        { new: true }
      );

      if (updatedTransaction) {
        res.status(200).json(updatedTransaction);
      } else {
        res.status(404).json({ message: "Transaction not found" });
      }
    } catch (error) {
      console.error("Error updating transaction:", error);
      res.status(400).json({ error: error.message });
    }
  }
);

module.exports = router;
