// edit_salesorder.js

document.addEventListener("DOMContentLoaded", () => {
  const editSalesOrderForm = document.getElementById("editSalesOrderForm");

  const urlParams = new URLSearchParams(window.location.search);
  const orderId = urlParams.get("orderId");

  const fetchSalesOrder = async () => {
    try {
      const response = await fetch(
        `http://localhost:3001/api/sales-orders/${orderId}`
      );
      if (response.ok) {
        const salesOrder = await response.json();
        // Populate form fields with sales order data
        document.getElementById("orderId").value = salesOrder.orderId;
        document.getElementById("customerId").value = salesOrder.customerId;
        document.getElementById("orderDate").value = salesOrder.orderDate;
        document.getElementById("orderStatus").value = salesOrder.orderStatus;
        document.getElementById("productID").value = salesOrder.productID;
        document.getElementById("quantity").value = salesOrder.quantity;
      } else {
        console.error("Failed to fetch sales order for editing");
      }
    } catch (error) {
      console.error("Error:", error);
    }
  };

  editSalesOrderForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    const updatedData = {
      orderId: document.getElementById("orderId").value,
      customerId: document.getElementById("customerId").value,
      orderDate: document.getElementById("orderDate").value,
      orderStatus: document.getElementById("orderStatus").value,
      productID: document.getElementById("productID").value,
      quantity: parseInt(document.getElementById("quantity").value),
    };

    try {
      const response = await fetch(
        `http://localhost:3001/api/sales-orders/${orderId}`,
        {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(updatedData),
        }
      );

      if (response.ok) {
        alert("Sales order updated successfully!");
        // Redirect back to sales orders page after update
        window.location.href = "salesorders.html";
      } else {
        console.error("Failed to update sales order");
      }
    } catch (error) {
      console.error("Error:", error);
    }
  });

  // Fetch sales order details when the edit page loads
  fetchSalesOrder();
});
