//Models/Transaction.js

const mongoose = require("mongoose");

const transactionSchema = new mongoose.Schema({
  transactionId: { type: String, required: true },
  productID: { type: String, required: true },
  transactionType: { type: String, required: true },
  transactionDate: { type: Date, required: true },
  quantity: { type: Number, required: true },
  unitPrice: { type: Number, required: true },
  transactionAmount: { type: Number, required: true },
  supplierId: { type: String },
  customerId: { type: String },
});

const Transaction = mongoose.model("Transaction", transactionSchema);

module.exports = Transaction;
