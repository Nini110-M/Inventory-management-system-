document.addEventListener("DOMContentLoaded", () => {
  const editProductForm = document.getElementById("editProductForm");

  const urlParams = new URLSearchParams(window.location.search);
  const productId = urlParams.get("id");

  const fetchProduct = async () => {
    try {
      const response = await fetch(
        `http://localhost:3001/api/products/${productId}`
      );
      if (response.ok) {
        const product = await response.json();
        // Populate form fields with product data
        document.getElementById("productID").value = product.productID;
        document.getElementById("productName").value = product.productName;
        document.getElementById("category").value = product.category;
        document.getElementById("unitPrice").value = product.unitPrice;
        document.getElementById("quantityInStock").value =
          product.quantityInStock;
        document.getElementById("reorderLevel").value = product.reorderLevel;
        document.getElementById("supplierName").value = product.supplierName;
      } else {
        console.error("Failed to fetch product for editing");
      }
    } catch (error) {
      console.error("Error:", error);
    }
  };

  editProductForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    const updatedData = {
      productID: document.getElementById("productID").value,
      productName: document.getElementById("productName").value,
      category: document.getElementById("category").value,
      unitPrice: Number(document.getElementById("unitPrice").value),
      quantityInStock: Number(document.getElementById("quantityInStock").value),
      reorderLevel: Number(document.getElementById("reorderLevel").value),
      supplierName: document.getElementById("supplierName").value,
    };

    try {
      const response = await fetch(
        `http://localhost:3001/api/products/${productId}`,
        {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(updatedData),
        }
      );

      if (response.ok) {
        alert("Product updated successfully!");
        // Redirect back to products page after update
        window.location.href = "products.html";
      } else {
        console.error("Failed to update product");
      }
    } catch (error) {
      console.error("Error:", error);
    }
  });

  // Fetch product details when the edit page loads
  fetchProduct();
});
